import React, { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { GroceryItem } from "@/lib/types";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Loader2, ShoppingBasket, PlusCircle, X, Search, ShoppingCart } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface GroceryListInputProps {
  groceryItems: GroceryItem[];
  isLoading: boolean;
  onCalculateStrategies: () => void;
}

export default function GroceryListInput({ 
  groceryItems, 
  isLoading,
  onCalculateStrategies 
}: GroceryListInputProps) {
  const [newItem, setNewItem] = useState("");
  const [isAddingItem, setIsAddingItem] = useState(false);
  const [isDeletingItem, setIsDeletingItem] = useState<number | null>(null);
  const { toast } = useToast();

  const handleAddItem = async () => {
    if (!newItem.trim()) {
      toast({
        title: "Please enter an item",
        description: "The item name cannot be empty.",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsAddingItem(true);
      await apiRequest("POST", "/api/grocery-items", { name: newItem });
      queryClient.invalidateQueries({ queryKey: ["/api/grocery-items"] });
      setNewItem("");
      toast({
        title: "Item added",
        description: `"${newItem}" has been added to your grocery list.`,
      });
    } catch (error) {
      toast({
        title: "Failed to add item",
        description: "There was an error adding the item. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsAddingItem(false);
    }
  };

  const handleRemoveItem = async (id: number) => {
    try {
      setIsDeletingItem(id);
      await apiRequest("DELETE", `/api/grocery-items/${id}`);
      queryClient.invalidateQueries({ queryKey: ["/api/grocery-items"] });
      toast({
        title: "Item removed",
        description: "The item has been removed from your grocery list.",
      });
    } catch (error) {
      toast({
        title: "Failed to remove item",
        description: "There was an error removing the item. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsDeletingItem(null);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleAddItem();
    }
  };

  return (
    <section className="mb-8">
      <Card className="mb-6 shadow-md border-none">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center text-xl">
            <ShoppingCart className="h-5 w-5 mr-2 text-primary" />
            Your Grocery List
            <Badge variant="outline" className="ml-2 bg-primary/10">
              {groceryItems.length} {groceryItems.length === 1 ? 'item' : 'items'}
            </Badge>
          </CardTitle>
        </CardHeader>
        
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-2 mb-6">
            <div className="flex-grow">
              <div className="relative">
                <Input
                  id="groceryItem"
                  placeholder="Add an item (e.g., milk, eggs, bread)"
                  value={newItem}
                  onChange={(e) => setNewItem(e.target.value)}
                  onKeyDown={handleKeyDown}
                  className="pr-10 focus-visible:ring-primary"
                  disabled={isAddingItem}
                />
                <button 
                  className="absolute right-2 top-1/2 transform -translate-y-1/2 text-primary hover:text-primary/80" 
                  aria-label="Add item"
                  onClick={handleAddItem}
                  disabled={isAddingItem}
                >
                  <PlusCircle className="h-5 w-5" />
                </button>
              </div>
            </div>
            <Button 
              onClick={handleAddItem}
              disabled={isAddingItem}
              className="sm:w-auto"
            >
              {isAddingItem ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Adding...
                </>
              ) : (
                <>Add Item</>
              )}
            </Button>
          </div>
          
          <div className="bg-gray-100 rounded-lg p-3 shadow-inner">
            {groceryItems.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <ShoppingBasket className="h-8 w-8 text-gray-400" />
                </div>
                <p className="text-lg font-medium">Your grocery list is empty</p>
                <p className="text-sm mt-1 text-gray-400 max-w-xs mx-auto">
                  Add items above to start finding the best deals across local stores
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {groceryItems.map((item) => (
                  <div 
                    key={item.id}
                    className="flex items-center justify-between py-3 px-4 bg-white rounded-md border border-gray-300 shadow-sm hover:shadow-md transition-shadow group"
                  >
                    <span className="font-medium text-gray-900">{item.name}</span>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-gray-400 hover:text-red-500 hover:bg-red-50 opacity-0 group-hover:opacity-100 transition-opacity" 
                      onClick={() => handleRemoveItem(item.id)}
                      disabled={isDeletingItem === item.id}
                      aria-label="Remove item"
                    >
                      {isDeletingItem === item.id ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <X className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
      
      <div className="text-center">
        <Button 
          variant="default"
          className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white px-8 py-6 shadow-lg rounded-full flex items-center mx-auto font-medium"
          onClick={onCalculateStrategies}
          disabled={isLoading || groceryItems.length === 0}
          size="lg"
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              Finding the Best Deals...
            </>
          ) : (
            <>
              <Search className="mr-2 h-5 w-5" />
              Find the Best Deals
            </>
          )}
        </Button>
        <p className="text-sm text-gray-500 mt-3">
          We'll analyze prices at nearby stores to save you money
        </p>
      </div>
    </section>
  );
}
