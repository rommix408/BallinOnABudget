import React from 'react';
import { Store } from '@shared/schema';
import { MapPin, Clock, CircleDollarSign, ExternalLink, AlertTriangle, MapPinned } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface StoreListProps {
  stores: Store[];
  maxDistance: number;
  error?: Error;
  selectedStore?: Store | null;
  onStoreSelect?: (store: Store) => void;
}

export default function StoreList({ 
  stores, 
  maxDistance, 
  error,
  selectedStore,
  onStoreSelect
}: StoreListProps) {
  // Filter stores based on maxDistance
  const filteredStores = stores.filter(store => store.distance <= maxDistance);

  // Sort stores by distance
  const sortedStores = [...filteredStores].sort((a, b) => a.distance - b.distance);

  // Show error state but still display any available stores
  const hasApiError = Boolean(error && error.message.includes('API'));
  
  if (sortedStores.length === 0 && !hasApiError) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-6 text-center">
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 max-w-md">
          <h3 className="text-lg font-medium text-amber-800">No Stores Found</h3>
          <p className="mt-2 text-amber-700">
            No stores were found within {maxDistance} miles of your location. Try increasing your maximum travel distance.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full overflow-y-auto p-2">
      {/* API error banner that appears above the store list */}
      {hasApiError && (
        <div className="mb-4 p-3 bg-amber-50 border border-amber-200 rounded-md">
          <div className="flex items-start">
            <AlertTriangle className="h-4 w-4 text-amber-500 mt-0.5 mr-2 flex-shrink-0" />
            <div>
              <p className="text-sm font-medium text-amber-800">
                Limited functionality
              </p>
              <p className="text-xs text-amber-700 mt-1">
                {error?.message || "Google Maps API service is limited. Some store information may be incomplete."}
              </p>
              <p className="text-xs mt-2 text-gray-600">
                Displaying available store data. Distance and travel time information may be estimated.
              </p>
            </div>
          </div>
        </div>
      )}
      
      <div className="grid grid-cols-1 gap-4">
        {sortedStores.map((store) => {
          // Check if this store is currently selected
          const isSelected = selectedStore && (selectedStore.id === store.id || 
            (selectedStore.name === store.name && selectedStore.address === store.address));
          
          return (
            <Card 
              key={store.id || store.name} 
              className={`overflow-hidden hover:shadow-md transition-all cursor-pointer 
                ${isSelected ? 'ring-2 ring-primary shadow-md bg-primary/5' : ''}
              `}
              onClick={() => {
                // Call provided handler if it exists
                if (onStoreSelect) {
                  onStoreSelect(store);
                }
                // Also use the globally exposed function as a fallback
                else if (window && (window as any).selectStoreFromList) {
                  (window as any).selectStoreFromList(store);
                } else {
                  console.error('No store selection mechanism available');
                }
              }}
            >
              <div className="p-4">
                <div className="flex justify-between items-start">
                  <h3 className="text-lg font-semibold">{store.name}</h3>
                  <span className="bg-green-100 text-green-800 text-xs font-medium px-2 py-1 rounded">
                    {store.distance.toFixed(1)} miles
                  </span>
                </div>
                
                {store.address && (
                  <div className="flex items-start mt-2">
                    <MapPin className="h-4 w-4 text-gray-500 mt-0.5 mr-1.5 flex-shrink-0" />
                    <p className="text-sm text-gray-600">{store.address}</p>
                  </div>
                )}
                
                <div className="flex items-center mt-2">
                  <Clock className="h-4 w-4 text-gray-500 mr-1.5 flex-shrink-0" />
                  <p className="text-sm text-gray-600">Travel time: <span className="font-medium">{store.travelTime} mins</span></p>
                </div>
                
                {/* Price level indicator (optional feature for future) */}
                <div className="flex items-center mt-2">
                  <CircleDollarSign className="h-4 w-4 text-gray-500 mr-1.5 flex-shrink-0" />
                  <p className="text-sm text-gray-600">
                    Price level: <span className="font-medium">$$$</span>
                  </p>
                </div>
                
                <div className="mt-4 flex justify-between">
                  <Button 
                    variant={isSelected ? "default" : "ghost"}
                    size="sm" 
                    className={`flex items-center ${isSelected ? 'text-white' : 'text-blue-600'}`}
                    onClick={(e) => {
                      // Prevent event from bubbling up to the card
                      e.stopPropagation();
                      
                      // Call provided handler if it exists
                      if (onStoreSelect) {
                        onStoreSelect(store);
                      }
                      // Also use the globally exposed function as a fallback
                      else if (window && (window as any).selectStoreFromList) {
                        (window as any).selectStoreFromList(store);
                      } else {
                        console.error('No store selection mechanism available');
                      }
                    }}
                  >
                    <MapPinned className="mr-1 h-3.5 w-3.5" />
                    <span>Show on map</span>
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex items-center"
                    onClick={(e) => {
                      // Prevent event from bubbling up to the card
                      e.stopPropagation();
                      
                      // Open directions in Google Maps
                      if (store.lat && store.lng) {
                        const url = `https://www.google.com/maps/dir/?api=1&destination=${store.lat},${store.lng}&travelmode=driving`;
                        window.open(url, '_blank');
                      }
                    }}
                  >
                    <span>Directions</span>
                    <ExternalLink className="ml-1 h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            </Card>
          );
        })}
      </div>
      
      <div className="p-3 mt-4 bg-gray-50 rounded-lg text-center">
        <p className="text-sm text-gray-600">Showing {sortedStores.length} stores within {maxDistance} miles</p>
      </div>
    </div>
  );
}