import React from "react";
import { Icon } from "./ui/icon";
import { useAuth } from "@/hooks/use-auth";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ShoppingCart, User, Settings, LogOut, Bell } from "lucide-react";

interface AppHeaderProps {
  notificationCount?: number;
}

export default function AppHeader({ notificationCount = 0 }: AppHeaderProps) {
  const { user, logoutMutation } = useAuth();
  const [, setLocation] = useLocation();
  
  // Generate user initials from first and last name
  const getUserInitials = () => {
    if (!user) return "?";
    
    const firstName = user.firstName || "";
    const lastName = user.lastName || "";
    
    return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase();
  };
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  return (
    <header className="bg-primary text-white shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="flex items-center" onClick={() => setLocation("/")}>
              <ShoppingCart className="mr-2 h-6 w-6 cursor-pointer" />
              <h1 className="text-xl font-medium cursor-pointer">BallinOnABudget</h1>
            </div>
            
            {/* Main navigation */}
            <nav className="hidden md:flex ml-8 space-x-6">
              <Link 
                href="/"
                className="text-white/90 hover:text-white transition-colors py-2 font-medium"
              >
                Home
              </Link>
              <Link 
                href="/lists"
                className="text-white/90 hover:text-white transition-colors py-2 font-medium"
              >
                Lists
              </Link>
              <Link 
                href="/stores"
                className="text-white/90 hover:text-white transition-colors py-2 font-medium"
              >
                Stores
              </Link>
              <Link 
                href="/profile"
                className="text-white/90 hover:text-white transition-colors py-2 font-medium"
              >
                Profile
              </Link>
            </nav>
          </div>
          
          <div className="flex items-center space-x-4">
            
            {user ? (
              // User is logged in - show profile avatar with dropdown
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative p-0 rounded-full h-8 w-8 focus-visible:ring-0">
                    <Avatar className="h-8 w-8 cursor-pointer">
                      <AvatarImage src="" alt={`${user.firstName} ${user.lastName}`} />
                      <AvatarFallback className="bg-blue-400 text-white">
                        {getUserInitials()}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end">
                  <DropdownMenuLabel>
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium">{user.firstName} {user.lastName}</p>
                      <p className="text-xs text-muted-foreground">{user.email}</p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => setLocation("/profile")}>
                    <User className="mr-2 h-4 w-4" />
                    <span>Profile</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLocation("/profile")}>
                    <Settings className="mr-2 h-4 w-4" />
                    <span>Settings</span>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Log out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              // User is not logged in - show login/signup buttons
              <div className="flex items-center space-x-2">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="text-white hover:bg-primary-dark"
                  onClick={() => setLocation("/auth")}
                >
                  Sign in
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="bg-white text-primary hover:bg-gray-100"
                  onClick={() => {
                    setLocation("/auth");
                    // Can add logic to switch to register tab if needed
                  }}
                >
                  Sign up
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
