import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { GoogleMap, useJsApiLoader, Marker, InfoWindow, Circle } from '@react-google-maps/api';
import { Store } from '@shared/schema';
import { Loader2 } from 'lucide-react';

interface StoreMapProps {
  stores: Store[];
  userLocation: { lat: number; lng: number } | null;
  maxDistance: number;
  selectedStore?: Store | null;
  onSelectStore?: (store: Store) => void;
}

export default function StoreMap({ 
  stores, 
  userLocation, 
  maxDistance, 
  selectedStore: externalSelectedStore,
  onSelectStore 
}: StoreMapProps) {
  const [internalSelectedStore, setInternalSelectedStore] = useState<Store | null>(null);
  
  // Use external selectedStore if provided, otherwise use internal state
  const selectedStore = externalSelectedStore !== undefined ? externalSelectedStore : internalSelectedStore;
  const [map, setMap] = useState<any>(null);
  const radiusCircleRef = React.useRef<any>(null);
  const markersRef = React.useRef<any[]>([]);

  // Load the Google Maps JS API
  const googleMapsApiKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';
  
  const { isLoaded, loadError } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey,
    libraries: ['places', 'geometry']
  });
  
  // Log any load errors
  useEffect(() => {
    if (loadError) {
      console.error('Google Maps loading error details:', loadError);
    }
  }, [loadError]);
  
  // Cleanup function to remove all Google Maps objects
  const cleanupMapObjects = useCallback(() => {
    // Clean up circle
    if (radiusCircleRef.current) {
      console.log('Cleaning up radius circle');
      radiusCircleRef.current.setMap(null);
      radiusCircleRef.current = null;
    }
    
    // Clean up any manually created markers (if we use those)
    if (markersRef.current.length > 0) {
      console.log(`Cleaning up ${markersRef.current.length} markers`);
      markersRef.current.forEach(marker => {
        if (marker) marker.setMap(null);
      });
      markersRef.current = [];
    }
  }, []);
  
  // When component unmounts, clean up all Map objects
  useEffect(() => {
    return () => {
      console.log('StoreMap component unmounting - cleaning up all map objects');
      cleanupMapObjects();
    };
  }, [cleanupMapObjects]);
  
  // Debug log for marker coordinates
  useEffect(() => {
    console.log('== DEBUG: MARKER COORDINATES ==',
      (filteredStores || []).map(store => ({
        id: store.id,
        name: store.name,
        coords: [store.lat, store.lng]
      }))
    );
  }, [filteredStores]);

  // Update circle when userLocation or maxDistance changes
  useEffect(() => {
    if (map && userLocation && isLoaded) {
      // Clear any existing circle
      if (radiusCircleRef.current) {
        radiusCircleRef.current.setMap(null);
        radiusCircleRef.current = null;
      }
      
      // Create new circle using the google object from the loaded maps API
      if (window.google && window.google.maps) {
        // Log that we're creating a new circle
        console.log('Creating new radius circle with center:', userLocation, 'and radius:', maxDistance, 'miles');
        
        radiusCircleRef.current = new window.google.maps.Circle({
          center: userLocation,
          radius: maxDistance * 1609.34, // Convert miles to meters
          fillColor: '#4338ca',
          fillOpacity: 0.15,
          strokeColor: '#4338ca',
          strokeOpacity: 0.9,
          strokeWeight: 3,
          map: map,
          zIndex: 1 // Ensure the circle appears under the markers
        });
      }
    }
    
    // Cleanup on unmount or when dependencies change
    return () => {
      if (radiusCircleRef.current) {
        console.log('Cleaning up radius circle due to dependency change');
        radiusCircleRef.current.setMap(null);
        radiusCircleRef.current = null;
      }
    };
  }, [map, userLocation, maxDistance, isLoaded]);

  // Filter stores based on maxDistance
  const filteredStores = useMemo(() => {
    if (!maxDistance) return stores;
    
    // Log EVERY detail about the stores being processed - most comprehensive logging
    console.log('*** COMPREHENSIVE STORE DATA ***');
    stores.forEach((store, index) => {
      console.log(`Store ${index}:`, JSON.stringify(store, null, 2));
    });
    
    return stores.filter(store => {
      // Create a debug ID for this store for tracking
      const debugId = store.id || store.name || `unknown-${Math.random().toString(36).substr(2, 5)}`;
      
      // First check for basic invalid data
      const lat = store.lat ?? 0;
      const lng = store.lng ?? 0;
      
      if (!lat || !lng || isNaN(lat) || isNaN(lng)) {
        console.log(`FILTERED OUT [${debugId}]: Missing or invalid coordinates`, 
          {lat, lng, isLatNaN: isNaN(lat), isLngNaN: isNaN(lng)});
        return false;
      }
      
      // Check distance filter
      if (store.distance > maxDistance) {
        console.log(`FILTERED OUT [${debugId}]: Distance ${store.distance} > max ${maxDistance}`);
        return false;
      }
      
      // Check if it's an actual grocery store (must have name AND address)
      if (!store.name || !store.address) {
        console.log(`FILTERED OUT [${debugId}]: Not a valid store - missing name or address`, 
          {name: store.name, hasAddress: !!store.address});
        return false;
      }
      
      console.log(`INCLUDED [${debugId}]: Valid store to display`, 
        {name: store.name, lat: store.lat, lng: store.lng, distance: store.distance});
      return true;
    });
  }, [stores, maxDistance]);

  // Calculate map center and zoom level
  const mapCenter = useMemo(() => {
    if (userLocation) return userLocation;
    
    // If no user location, center the map on the first store or a default location
    if (filteredStores.length > 0 && filteredStores[0].lat && filteredStores[0].lng) {
      return { lat: filteredStores[0].lat, lng: filteredStores[0].lng };
    }
    
    // Default to a central US location
    return { lat: 37.0902, lng: -95.7129 };
  }, [userLocation, filteredStores]);
  
  // Calculate appropriate zoom level based on radius
  const zoomLevel = useMemo(() => {
    if (!maxDistance) return 10;
    // Smaller zoom number means more zoomed out
    if (maxDistance > 20) return 9;
    if (maxDistance > 15) return 10;
    if (maxDistance > 10) return 11;
    if (maxDistance > 5) return 12;
    return 13; // Closer zoom for small radius
  }, [maxDistance]);

  // Function to handle store selection from map markers or list
  const selectStore = useCallback((store: Store) => {
    console.log('Store selected:', store.name);
    setInternalSelectedStore(store);
    // Also call the parent's handler if provided
    if (onSelectStore) onSelectStore(store);
  }, [onSelectStore]);
  
  // Expose the selectStore function publicly
  useEffect(() => {
    // Make the selectStore function available globally for debugging
    (window as any).selectStoreFromList = selectStore;
  }, [selectStore]);

  const onInfoWindowClose = useCallback(() => {
    setInternalSelectedStore(null);
    if (onSelectStore) onSelectStore(null as any);
  }, [onSelectStore]);

  const mapContainerStyle = {
    width: '100%',
    height: '100%',
  };

  if (!isLoaded) {
    return (
      <div className="h-full flex flex-col items-center justify-center bg-gray-100 p-4">
        {!loadError && (
          <>
            <Loader2 className="h-8 w-8 animate-spin text-primary mb-2" />
            <span className="text-center">Loading Google Maps...</span>
          </>
        )}
        
        {/* API Key Information */}
        <div className="mt-3 text-center">
          <p className="text-xs text-gray-600">
            API Key status: {googleMapsApiKey ? 'Provided' : 'Missing'}
            {googleMapsApiKey && ` (length: ${googleMapsApiKey.length})`}
          </p>
        </div>
        
        {/* Error information if present */}
        {loadError && (
          <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-md max-w-md text-center">
            <p className="text-sm text-red-700 font-medium">Error loading Google Maps</p>
            <p className="text-sm text-red-700 mt-1">{loadError.message || "API Key may be invalid"}</p>
            
            {loadError.message && loadError.message.includes('API key') && (
              <div className="mt-3 p-2 bg-white rounded text-sm">
                <p className="font-medium text-red-800">API Key Error</p>
                <p className="text-xs mt-1">The Google Maps API key appears to be invalid or missing.</p>
                <p className="text-xs mt-1">Please make sure you:</p>
                <ul className="text-xs mt-1 list-disc list-inside">
                  <li>Have a valid Google Maps API key</li>
                  <li>Have billing enabled on your Google Cloud account</li>
                  <li>Have enabled the necessary APIs in your Google Cloud Console</li>
                </ul>
              </div>
            )}
            
            <p className="text-xs text-red-600 mt-3">Error code: {(loadError as any).code || 'Unknown'}</p>
            <p className="text-xs text-red-600 mt-1">Please ensure the Google Maps API key is enabled for:</p>
            <ul className="text-xs text-red-600 mt-1 list-disc list-inside">
              <li>Maps JavaScript API</li>
              <li>Places API</li>
              <li>Distance Matrix API</li>
              <li>Geocoding API</li>
            </ul>
            
            <div className="mt-4 text-xs">
              <p className="text-gray-500">
                This application requires Google Maps to function properly.
                Until the API key issue is resolved, store locations and directions will be unavailable.
              </p>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="h-full relative">
      <GoogleMap
        mapContainerStyle={mapContainerStyle}
        center={mapCenter}
        zoom={zoomLevel}
        options={{
          // Complete custom styling to remove ALL default markers
          styles: [
            // Disable all points of interest
            { featureType: "poi", stylers: [{ visibility: "off" }] },
            { featureType: "poi.business", stylers: [{ visibility: "off" }] },
            { featureType: "poi.park", stylers: [{ visibility: "off" }] },
            { featureType: "poi.attraction", stylers: [{ visibility: "off" }] },
            { featureType: "poi.school", stylers: [{ visibility: "off" }] },
            { featureType: "poi.government", stylers: [{ visibility: "off" }] },
            { featureType: "poi.medical", stylers: [{ visibility: "off" }] },
            { featureType: "poi.place_of_worship", stylers: [{ visibility: "off" }] },
            { featureType: "transit", stylers: [{ visibility: "off" }] },
            { featureType: "transit.station", stylers: [{ visibility: "off" }] }
          ],
          clickableIcons: false, // Critical - prevents clicking on default POIs
          disableDefaultUI: true, // Disable all UI elements
          zoomControl: true,      // But re-enable zoom controls
          scaleControl: true,     // And scale for distance reference
          rotateControl: false,
          mapTypeControl: false,
          streetViewControl: false,
          fullscreenControl: false
        }}
        onLoad={(mapInstance) => {
          console.log('Map instance loaded - clearing any previous markers');
          setMap(mapInstance);
          
          // Clean up any previous map objects when the map is loaded
          cleanupMapObjects();
        }}
      >
        {/* User location marker */}
        {userLocation && (
          <Marker
            position={userLocation}
            icon={{
              path: window.google?.maps?.SymbolPath?.CIRCLE || 0,
              scale: 10,
              fillColor: '#4338ca',
              fillOpacity: 1,
              strokeColor: '#ffffff',
              strokeWeight: 2,
            }}
            title="Your Location"
          />
        )}

        {/* DEBUGGING: Add debug console output for all marker locations */}
        {/* Remove console.log from JSX and move to useEffect */}
        
        {/* Display store markers on the map */}
        {filteredStores.map((store) => (
          store.lat && store.lng ? (
            <Marker
              key={store.id || store.name}
              position={{ lat: store.lat, lng: store.lng }}
              icon={{
                url: 'https://maps.google.com/mapfiles/ms/icons/green-dot.png', // Green marker for stores
                scaledSize: new window.google.maps.Size(32, 32),
                origin: new window.google.maps.Point(0, 0),
                anchor: new window.google.maps.Point(16, 32),
              }}
              title={store.name}
              onClick={() => selectStore(store)}
            />
          ) : null
        ))}
        
        {/* Info window for selected store */}
        {selectedStore && selectedStore.lat && selectedStore.lng && (
          <InfoWindow
            position={{ lat: selectedStore.lat, lng: selectedStore.lng }}
            onCloseClick={onInfoWindowClose}
          >
            <div className="p-2 max-w-xs">
              <h3 className="font-semibold text-lg">{selectedStore.name}</h3>
              {selectedStore.address && (
                <p className="text-sm text-gray-600 mt-1">{selectedStore.address}</p>
              )}
              <div className="mt-2 text-sm">
                <p className="font-medium">Distance: <span className="font-normal">{selectedStore.distance.toFixed(1)} miles</span></p>
                {selectedStore.travelTime && (
                  <p className="font-medium">Travel time: <span className="font-normal">{selectedStore.travelTime} mins</span></p>
                )}
              </div>
            </div>
          </InfoWindow>
        )}
      </GoogleMap>

      {/* Distance radius indicator */}
      <div className="absolute bottom-4 right-4 bg-white px-3 py-2 shadow-md rounded-md text-sm">
        <p className="font-medium text-gray-700">Max distance: {maxDistance} miles</p>
        <p className="text-gray-500 text-xs">{filteredStores.length} store(s) found</p>
      </div>
    </div>
  );
}