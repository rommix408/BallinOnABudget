// Type definitions for global objects

interface Window {
  google?: {
    maps?: any;
  };
}