import React, { useState } from 'react';
import { useLocation, Redirect } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { useUserPreferences } from '@/hooks/use-user-preferences';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Slider } from '@/components/ui/slider';
import { toast } from '@/hooks/use-toast';
import { UserPreferences } from '@/lib/types';
import AppHeader from '@/components/AppHeader';
import { Loader2 } from 'lucide-react';
import BottomNavigation from '@/components/BottomNavigation';

// Validation schema for the user profile form
const profileFormSchema = z.object({
  homeAddress: z.string().optional(),
  zipCode: z.string().optional(),
  maxTravelDistance: z.number().min(1).max(50),
  preferSaleItems: z.boolean(),
  emailNotifications: z.boolean(),
  smsNotifications: z.boolean(),
  saveSearchHistory: z.boolean(),
});

type ProfileFormValues = z.infer<typeof profileFormSchema>;

export default function ProfilePage() {
  const [activeTab, setActiveTab] = useState('personal');
  const { user, isLoading: authLoading } = useAuth();
  const { preferences, isLoading, updatePreferences, isUpdating } = useUserPreferences();
  
  // If not logged in, redirect to auth page
  if (!authLoading && !user) {
    return <Redirect to="/auth" />;
  }
  
  if (authLoading || isLoading) {
    return (
      <div className="flex flex-col min-h-screen">
        <AppHeader />
        <div className="flex-1 flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
        <BottomNavigation activeTab="profile" />
      </div>
    );
  }
  
  return (
    <div className="flex flex-col min-h-screen">
      <AppHeader />
      
      <main className="flex-1 container max-w-5xl mx-auto p-4 md:p-8">
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Profile & Settings</h1>
            <p className="text-muted-foreground">
              Manage your account preferences and settings
            </p>
          </div>
          
          <Separator className="my-6" />
          
          <Tabs defaultValue="personal" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
            <TabsList>
              <TabsTrigger value="personal">Personal Information</TabsTrigger>
              <TabsTrigger value="shopping">Shopping Preferences</TabsTrigger>
            </TabsList>
            
            <TabsContent value="personal">
              <PersonalInfoTab 
                user={user} 
                preferences={preferences} 
                onUpdate={updatePreferences}
                isUpdating={isUpdating}
              />
            </TabsContent>
            
            <TabsContent value="shopping">
              <ShoppingPreferencesTab 
                preferences={preferences} 
                onUpdate={updatePreferences}
                isUpdating={isUpdating}
              />
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      <BottomNavigation activeTab="profile" />
    </div>
  );
}

interface TabProps {
  user?: any;
  preferences?: UserPreferences;
  onUpdate: (data: Partial<UserPreferences>) => void;
  isUpdating: boolean;
}

function PersonalInfoTab({ user, preferences, onUpdate, isUpdating }: TabProps) {
  // Create form with default values from user and preferences
  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      homeAddress: preferences?.homeAddress || '',
      zipCode: preferences?.zipCode || '',
      maxTravelDistance: preferences?.maxTravelDistance || 10,
      preferSaleItems: preferences?.preferSaleItems ?? true,
      emailNotifications: preferences?.emailNotifications ?? true,
      smsNotifications: preferences?.smsNotifications ?? false,
      saveSearchHistory: preferences?.saveSearchHistory ?? true,
    },
  });
  
  function onSubmit(data: ProfileFormValues) {
    onUpdate(data);
  }
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Personal Information</CardTitle>
        <CardDescription>
          Update your personal information and address to get better recommendations
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <FormField
                    control={form.control}
                    name="homeAddress"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Home Address</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter your home address" {...field} />
                        </FormControl>
                        <FormDescription>
                          This helps us find stores near you
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="zipCode"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>ZIP Code</FormLabel>
                      <FormControl>
                        <Input placeholder="ZIP Code" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="maxTravelDistance"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Maximum Travel Distance ({field.value} miles)</FormLabel>
                      <FormControl>
                        <Slider
                          min={1}
                          max={50}
                          step={1}
                          defaultValue={[field.value]}
                          onValueChange={(vals) => field.onChange(vals[0])}
                        />
                      </FormControl>
                      <FormDescription>
                        How far are you willing to travel for grocery shopping?
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4">
                <FormField
                  control={form.control}
                  name="emailNotifications"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">Email Notifications</FormLabel>
                        <FormDescription>
                          Receive notifications via email
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="smsNotifications"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">SMS Notifications</FormLabel>
                        <FormDescription>
                          Receive notifications via text message
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>
            </div>
            
            <Button type="submit" className="w-full" disabled={isUpdating}>
              {isUpdating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                'Save Changes'
              )}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}

function ShoppingPreferencesTab({ preferences, onUpdate, isUpdating }: TabProps) {
  // Create form with default values from preferences
  const form = useForm<ProfileFormValues>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      homeAddress: preferences?.homeAddress || '',
      zipCode: preferences?.zipCode || '',
      maxTravelDistance: preferences?.maxTravelDistance || 10,
      preferSaleItems: preferences?.preferSaleItems ?? true,
      emailNotifications: preferences?.emailNotifications ?? true,
      smsNotifications: preferences?.smsNotifications ?? false,
      saveSearchHistory: preferences?.saveSearchHistory ?? true,
    },
  });
  
  function onSubmit(data: ProfileFormValues) {
    onUpdate(data);
  }
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Shopping Preferences</CardTitle>
        <CardDescription>
          Customize how we generate shopping strategies for you
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="space-y-4">
              <FormField
                control={form.control}
                name="preferSaleItems"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">Prefer Sale Items</FormLabel>
                      <FormDescription>
                        Prioritize stores with items on sale
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="saveSearchHistory"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">Save Search History</FormLabel>
                      <FormDescription>
                        Save your grocery lists for future use
                      </FormDescription>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="maxTravelDistance"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Maximum Travel Distance ({field.value} miles)</FormLabel>
                    <FormControl>
                      <Slider
                        min={1}
                        max={50}
                        step={1}
                        defaultValue={[field.value]}
                        onValueChange={(vals) => field.onChange(vals[0])}
                      />
                    </FormControl>
                    <FormDescription>
                      How far are you willing to travel for grocery shopping?
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <Button type="submit" className="w-full" disabled={isUpdating}>
              {isUpdating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                'Save Changes'
              )}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}