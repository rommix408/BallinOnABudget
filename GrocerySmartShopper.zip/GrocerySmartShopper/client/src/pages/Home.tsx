import React, { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import AppHeader from "@/components/AppHeader";
import GroceryListInput from "@/components/GroceryListInput";
import StrategySwitcher from "@/components/StrategySwitcher";
import StrategyDetails from "@/components/StrategyDetails";
import BottomNavigation from "@/components/BottomNavigation";
import { calculateStrategies } from "@/lib/strategies";
import { CalculateStrategiesResponse, GroceryItem, StrategyType, Store } from "@/lib/types";
import { Skeleton } from "@/components/ui/skeleton";
import { ShoppingCart, Sparkles, PiggyBank } from "lucide-react";

export default function Home() {
  const [activeStrategy, setActiveStrategy] = useState<StrategyType>("balanced");
  const [strategies, setStrategies] = useState<CalculateStrategiesResponse | null>(null);
  const { toast } = useToast();
  const { user } = useAuth();

  // Fetch grocery items
  const { 
    data: groceryItems = [] as GroceryItem[], 
    isLoading: isLoadingItems,
    error: itemsError,
  } = useQuery<GroceryItem[]>({
    queryKey: ["/api/grocery-items"],
  });

  // Fetch stores
  const {
    data: stores = [] as Store[], 
    isLoading: isLoadingStores,
    error: storesError,
  } = useQuery<Store[]>({
    queryKey: ["/api/stores"],
  });

  // Mutation for calculating strategies
  const {
    mutate: calculateStrategiesMutation,
    isPending: isCalculating,
  } = useMutation<CalculateStrategiesResponse, Error, void>({
    mutationFn: async () => {
      const itemNames = groceryItems.map((item) => item.name);
      return calculateStrategies(itemNames);
    },
    onSuccess: (data) => {
      setStrategies(data);
      toast({
        title: "Strategies calculated",
        description: "We found the best shopping options for your list.",
      });
      
      // Scroll to strategies section
      const strategiesElement = document.getElementById('strategies-section');
      if (strategiesElement) {
        strategiesElement.scrollIntoView({ behavior: 'smooth' });
      }
    },
    onError: () => {
      toast({
        title: "Calculation failed",
        description: "We couldn't calculate strategies. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleCalculateStrategies = () => {
    if (groceryItems.length === 0) {
      toast({
        title: "Empty grocery list",
        description: "Please add at least one item to your grocery list.",
        variant: "destructive",
      });
      return;
    }
    
    calculateStrategiesMutation();
  };

  const handleStrategyChange = (type: StrategyType) => {
    setActiveStrategy(type);
  };

  // Check for errors
  if (itemsError || storesError) {
    toast({
      title: "Error loading data",
      description: "There was an error loading the application data.",
      variant: "destructive",
    });
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-16 md:pb-6">
      <AppHeader />
      
      {/* Hero section with combined features */}
      <div className="bg-gradient-to-br from-primary to-primary-dark text-white py-10 px-4">
        <div className="container mx-auto max-w-5xl">
          <div className="text-center mb-8">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              Welcome {user ? `${user.firstName}` : ''} to BallinOnABudget
            </h1>
            <p className="text-xl opacity-90 max-w-2xl mx-auto">
              Save money and time on your grocery shopping with smart strategies
            </p>
          </div>
          
          {/* Combined feature grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {/* Feature 1 */}
            <div className="bg-purple-600/25 rounded-lg p-5 backdrop-blur-sm border border-purple-400/30 shadow-lg transform hover:scale-105 transition-transform">
              <div className="p-3 bg-purple-700 rounded-full w-12 h-12 flex items-center justify-center mb-3">
                <ShoppingCart className="h-5 w-5 text-white" />
              </div>
              <h3 className="text-lg font-semibold mb-2 text-white">Smart List Management</h3>
              <p className="text-white text-sm leading-relaxed">
                Easily create and manage your grocery lists for multiple stores
              </p>
            </div>
            
            {/* Feature 2 */}
            <div className="bg-green-600/25 rounded-lg p-5 backdrop-blur-sm border border-green-400/30 shadow-lg transform hover:scale-105 transition-transform">
              <div className="p-3 bg-green-700 rounded-full w-12 h-12 flex items-center justify-center mb-3">
                <PiggyBank className="h-5 w-5 text-white" />
              </div>
              <h3 className="text-lg font-semibold mb-2 text-white">Price Comparison</h3>
              <p className="text-white text-sm leading-relaxed">
                Compare prices across different stores to find the best deals
              </p>
            </div>
            
            {/* Feature 3 */}
            <div className="bg-blue-600/25 rounded-lg p-5 backdrop-blur-sm border border-blue-400/30 shadow-lg transform hover:scale-105 transition-transform">
              <div className="p-3 bg-blue-700 rounded-full w-12 h-12 flex items-center justify-center mb-3">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
              <h3 className="text-lg font-semibold mb-2 text-white">Multiple Strategies</h3>
              <p className="text-white text-sm leading-relaxed">
                Choose from various shopping strategies based on your priorities
              </p>
            </div>
            
            {/* Feature 4 */}
            <div className="bg-orange-600/25 rounded-lg p-5 backdrop-blur-sm border border-orange-400/30 shadow-lg transform hover:scale-105 transition-transform">
              <div className="p-3 bg-orange-700 rounded-full w-12 h-12 flex items-center justify-center mb-3">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z" />
                  <path d="M12 6v6l4 2" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold mb-2 text-white">Time Optimization</h3>
              <p className="text-white text-sm leading-relaxed">
                Save time with optimized routes and store recommendations
              </p>
            </div>
          </div>
        </div>
      </div>
      
      <main className="container mx-auto px-4 py-6 max-w-5xl">
        {/* Loading state */}
        {isLoadingItems && (
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <Skeleton className="h-8 w-64 mb-4" />
            <div className="space-y-2">
              <Skeleton className="h-10 w-full mb-4" />
              <Skeleton className="h-16 w-full" />
            </div>
          </div>
        )}
        
        {/* Grocery list input section */}
        {!isLoadingItems && (
          <GroceryListInput 
            groceryItems={groceryItems} 
            isLoading={isCalculating}
            onCalculateStrategies={handleCalculateStrategies} 
          />
        )}
        
        {/* Strategies section with id for scrolling */}
        <div id="strategies-section">
          {strategies && (
            <>
              <StrategySwitcher 
                strategies={strategies}
                activeStrategy={activeStrategy}
                onStrategyChange={handleStrategyChange}
              />
              
              <StrategyDetails 
                strategies={strategies}
                activeStrategy={activeStrategy}
                stores={stores}
              />
            </>
          )}
        </div>
        
        {/* Empty state when no strategies and not loading */}
        {!strategies && !isCalculating && !isLoadingItems && groceryItems.length > 0 && (
          <div className="bg-white rounded-lg shadow-md p-8 text-center my-8">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Sparkles className="h-8 w-8 text-primary" />
            </div>
            <h2 className="text-xl font-semibold mb-3">Ready to Find the Best Deals?</h2>
            <p className="text-gray-600 mb-6 max-w-md mx-auto">
              Add your grocery items above and click "Find the Best Deals" to discover
              the most cost-effective shopping strategies.
            </p>
          </div>
        )}
      </main>
      
      <BottomNavigation activeTab="home" />
    </div>
  );
}
