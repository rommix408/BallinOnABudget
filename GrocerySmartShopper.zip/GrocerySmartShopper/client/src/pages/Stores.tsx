import React, { useState, useEffect } from "react";
import AppHeader from "@/components/AppHeader";
import BottomNavigation from "@/components/BottomNavigation";
import { useUserLocation } from "@/hooks/use-user-location";
import { useNearbyStores } from "@/hooks/use-nearby-stores";
import StoreMap from "@/components/StoreMap";
import StoreList from "@/components/StoreList";
import { Slider } from "@/components/ui/slider";
import { useUserPreferences } from "@/hooks/use-user-preferences";
import { Button } from "@/components/ui/button";
import { MapPin, Loader2 } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";

export default function Stores() {
  // Get user location and nearby stores
  const { location } = useUserLocation();
  const { stores, isLoading: isLoadingStores, maxTravelDistance } = useNearbyStores(location);
  
  // User preferences for updating max distance
  const { preferences, updatePreferences, isUpdating } = useUserPreferences();
  
  // Local state
  const [distanceFilter, setDistanceFilter] = useState<number>(maxTravelDistance || 10);
  const [viewMode, setViewMode] = useState<"map" | "list">("map");
  const [selectedStore, setSelectedStore] = useState<any>(null);
  const { toast } = useToast();

  // Update distance filter when maxTravelDistance changes
  useEffect(() => {
    if (maxTravelDistance && maxTravelDistance !== distanceFilter) {
      setDistanceFilter(maxTravelDistance);
    }
  }, [maxTravelDistance]);

  // Save distance preference
  const handleSavePreference = () => {
    if (preferences && distanceFilter !== preferences.maxTravelDistance) {
      updatePreferences({ maxTravelDistance: distanceFilter });
      
      toast({
        title: "Preference saved",
        description: `Max travel distance set to ${distanceFilter} miles`,
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <AppHeader />
      
      <main className="container mx-auto px-4 py-6 pb-16">
        {/* Distance slider */}
        <div className="bg-white rounded-lg p-4 mb-4 shadow-sm">
          <div className="flex items-center">
            <MapPin className="text-green-600 w-5 h-5" />
          </div>
          
          <Slider 
            value={[distanceFilter]}
            max={30}
            min={1}
            step={1}
            onValueChange={(values) => setDistanceFilter(values[0])}
            className="my-5"
          />
          
          <div className="flex justify-end">
            <Button 
              onClick={handleSavePreference}
              className="bg-green-500 hover:bg-green-600 text-white"
              disabled={isUpdating || (preferences && distanceFilter === preferences.maxTravelDistance)}
            >
              {isUpdating ? "Saving..." : "Save Preference"}
            </Button>
          </div>
        </div>
        
        {/* Map/List View */}
        <div className="bg-white rounded-lg shadow-sm">
          <Tabs defaultValue={viewMode} onValueChange={(value) => setViewMode(value as "map" | "list")}>
            <div className="flex justify-end p-2">
              <TabsList>
                <TabsTrigger value="map">Map</TabsTrigger>
                <TabsTrigger value="list">List</TabsTrigger>
              </TabsList>
            </div>
            
            <TabsContent value="map" className="h-[calc(100vh-280px)]">
              {isLoadingStores && (
                <div className="h-full flex items-center justify-center">
                  <Loader2 className="w-8 h-8 animate-spin text-primary" />
                </div>
              )}
              
              {!isLoadingStores && location && (
                <StoreMap 
                  stores={stores} 
                  userLocation={location} 
                  maxDistance={distanceFilter}
                  selectedStore={selectedStore}
                  onSelectStore={setSelectedStore}
                />
              )}
            </TabsContent>
            
            <TabsContent value="list">
              {isLoadingStores ? (
                <div className="flex items-center justify-center py-10">
                  <Loader2 className="w-8 h-8 animate-spin text-primary" />
                </div>
              ) : (
                <StoreList 
                  stores={stores}
                  maxDistance={distanceFilter}
                  error={undefined}
                  selectedStore={selectedStore}
                  onStoreSelect={setSelectedStore}
                />
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      <BottomNavigation activeTab="stores" />
    </div>
  );
}
