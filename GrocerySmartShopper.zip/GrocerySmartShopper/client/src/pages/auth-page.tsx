import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { formatPhoneNumber, formatPhoneForStorage, isValidUSPhoneNumber } from "@/lib/utils";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Loader2, ShoppingCart, Sparkles, Clock } from "lucide-react";

export default function AuthPage() {
  const { loginMutation, registerMutation, user, isLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  // If user is already logged in, redirect to home
  useEffect(() => {
    if (user) {
      setLocation("/");
    }
  }, [user, setLocation]);

  const [loginData, setLoginData] = useState({
    identifier: "", // Can be email or phone
    password: "",
  });

  const [registerData, setRegisterData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
  });

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Check for missing fields
    if (!loginData.identifier || !loginData.password) {
      toast({
        title: "Missing fields",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }
    
    // Validate identifier (email or phone)
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    const isValidEmail = emailRegex.test(loginData.identifier);
    
    // For phone, check if it's a valid US formatted number or an E.164 format
    const isFormattedPhone = isValidUSPhoneNumber(loginData.identifier.replace(/[\(\)\s\-]/g, ''));
    const isE164Phone = /^\+?1[0-9]{10}$/.test(loginData.identifier.replace(/[\(\)\s\-]/g, ''));
    
    if (!isValidEmail && !isFormattedPhone && !isE164Phone) {
      toast({
        title: "Invalid credentials",
        description: "Please enter a valid email address or phone number",
        variant: "destructive",
      });
      return;
    }
    
    // If identifier is a formatted phone number, convert to E.164 format for the server
    let identifier = loginData.identifier;
    if (isFormattedPhone) {
      identifier = formatPhoneForStorage(loginData.identifier);
    }
    
    // Check password is not empty - reduced requirement for testing
    if (loginData.password.length < 1) {
      toast({
        title: "Password required",
        description: "Password cannot be empty", 
        variant: "destructive",
      });
      return;
    }
    
    loginMutation.mutate({
      identifier: identifier,
      password: loginData.password
    });
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Check for missing fields
    if (!registerData.firstName || !registerData.lastName || !registerData.email || 
        !registerData.phone || !registerData.password || !registerData.confirmPassword) {
      toast({
        title: "Missing fields",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }
    
    // Validate email format
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailRegex.test(registerData.email)) {
      toast({
        title: "Invalid email",
        description: "Please enter a valid email address",
        variant: "destructive",
      });
      return;
    }
    
    // Validate phone number has 10 digits (US format)
    if (!isValidUSPhoneNumber(registerData.phone)) {
      toast({
        title: "Invalid phone number",
        description: "Please enter a valid 10-digit US phone number",
        variant: "destructive",
      });
      return;
    }
    
    // Check password is not empty - reduced requirement for testing
    if (registerData.password.length < 1) {
      toast({
        title: "Password required",
        description: "Password cannot be empty",
        variant: "destructive",
      });
      return;
    }
    
    // Check if passwords match
    if (registerData.password !== registerData.confirmPassword) {
      toast({
        title: "Passwords don't match",
        description: "Please make sure your passwords match",
        variant: "destructive",
      });
      return;
    }
    
    // Convert formatted phone number to E.164 format (+1XXXXXXXXXX) before sending to server
    const e164Phone = formatPhoneForStorage(registerData.phone);
    
    registerMutation.mutate({
      firstName: registerData.firstName,
      lastName: registerData.lastName,
      email: registerData.email,
      phone: e164Phone,
      password: registerData.password,
    });
  };

  return (
    <div className="flex min-h-screen">
      {/* Left side - Auth form */}
      <div className="w-full lg:w-1/2 p-8 flex items-center justify-center">
        <Tabs defaultValue="login" className="w-full max-w-md">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="login">Login</TabsTrigger>
            <TabsTrigger value="register">Register</TabsTrigger>
          </TabsList>
          
          <TabsContent value="login">
            <Card>
              <CardHeader>
                <CardTitle>Login</CardTitle>
                <CardDescription>
                  Enter your credentials to access your account
                </CardDescription>
              </CardHeader>
              <form onSubmit={handleLogin}>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <label htmlFor="identifier" className="text-sm font-medium">Email or Phone</label>
                    <Input 
                      id="identifier"
                      placeholder="Enter your email or phone number" 
                      value={loginData.identifier}
                      onChange={(e) => {
                        let value = e.target.value;
                        // If it looks like a phone number (has digits and no @ symbol)
                        if (value.match(/\d/) && !value.includes('@')) {
                          // Apply phone number formatting
                          value = formatPhoneNumber(value);
                        }
                        setLoginData({ ...loginData, identifier: value });
                      }}
                      maxLength={50} // Increase limit for email addresses
                    />
                    <p className="text-xs text-muted-foreground mt-1">Enter the email or phone number you used during registration</p>
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="password" className="text-sm font-medium">Password</label>
                    <Input 
                      id="password"
                      type="password" 
                      placeholder="Enter your password"
                      value={loginData.password}
                      onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                      maxLength={100} // Set a reasonable maximum for passwords
                    />
                  </div>
                </CardContent>
                <CardFooter>
                  <Button type="submit" className="w-full" disabled={loginMutation.isPending}>
                    {loginMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" /> 
                        Logging in...
                      </>
                    ) : (
                      'Log in'
                    )}
                  </Button>
                </CardFooter>
              </form>
            </Card>
          </TabsContent>
          
          <TabsContent value="register">
            <Card>
              <CardHeader>
                <CardTitle>Create an account</CardTitle>
                <CardDescription>
                  Enter your details to create your account
                </CardDescription>
              </CardHeader>
              <form onSubmit={handleRegister}>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <label htmlFor="firstName" className="text-sm font-medium">First Name</label>
                    <Input 
                      id="firstName"
                      placeholder="Enter your first name" 
                      value={registerData.firstName}
                      onChange={(e) => setRegisterData({ ...registerData, firstName: e.target.value })}
                      maxLength={30} // Set a sensible limit for names
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="lastName" className="text-sm font-medium">Last Name</label>
                    <Input 
                      id="lastName"
                      placeholder="Enter your last name" 
                      value={registerData.lastName}
                      onChange={(e) => setRegisterData({ ...registerData, lastName: e.target.value })}
                      maxLength={30} // Set a sensible limit for names
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="email" className="text-sm font-medium">Email</label>
                    <Input 
                      id="email"
                      type="email" 
                      placeholder="Enter your email"
                      value={registerData.email}
                      onChange={(e) => setRegisterData({ ...registerData, email: e.target.value })}
                      maxLength={50} // Set a sensible limit for email addresses
                    />
                    <p className="text-xs text-muted-foreground mt-1">You'll use this to login and receive shopping recommendations</p>
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="phone" className="text-sm font-medium">Phone Number</label>
                    <Input 
                      id="phone"
                      placeholder="Enter your phone number"
                      value={registerData.phone}
                      onChange={(e) => {
                        // Apply formatting as the user types
                        const formattedPhone = formatPhoneNumber(e.target.value);
                        setRegisterData({ ...registerData, phone: formattedPhone });
                      }}
                      maxLength={14} // (XXX) XXX-XXXX is 14 chars
                    />
                    <p className="text-xs text-muted-foreground mt-1">Format: US phone number (e.g., (555) 555-1234)</p>
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="register-password" className="text-sm font-medium">Password</label>
                    <Input 
                      id="register-password"
                      type="password" 
                      placeholder="Create a password"
                      value={registerData.password}
                      onChange={(e) => setRegisterData({ ...registerData, password: e.target.value })}
                      maxLength={100} // Set a reasonable maximum for passwords
                    />
                    <p className="text-xs text-muted-foreground mt-1">Password cannot be empty (reduced requirement for testing)</p>
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="confirm-password" className="text-sm font-medium">Confirm Password</label>
                    <Input 
                      id="confirm-password"
                      type="password" 
                      placeholder="Confirm your password"
                      value={registerData.confirmPassword}
                      onChange={(e) => setRegisterData({ ...registerData, confirmPassword: e.target.value })}
                      maxLength={100} // Match the password field maximum
                    />
                  </div>
                </CardContent>
                <CardFooter>
                  <Button type="submit" className="w-full" disabled={registerMutation.isPending}>
                    {registerMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" /> 
                        Creating account...
                      </>
                    ) : (
                      'Create account'
                    )}
                  </Button>
                </CardFooter>
              </form>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
      
      {/* Right side - Hero section */}
      <div className="hidden lg:flex lg:w-1/2 bg-green-700 p-8 text-white flex-col justify-center">
        <div className="max-w-lg mx-auto">
          <h1 className="text-4xl font-bold mb-4 text-center">Ballin' on a Budget</h1>
          <p className="text-lg mb-8 text-center">Your smart shopping assistant to save both money and time.</p>
          
          <div className="space-y-6">
            {/* Feature card 1 */}
            <div className="flex items-start space-x-4 bg-green-600/50 p-5 rounded-lg shadow-md border border-green-500/30">
              <div className="p-3 bg-purple-600 rounded-full shrink-0">
                <ShoppingCart className="h-5 w-5 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-semibold">Smart Shopping Lists</h3>
                <p className="text-sm text-white/90">
                  Create and manage your grocery lists in one place. Add items quickly and see the best deals.
                </p>
              </div>
            </div>
            
            {/* Feature card 2 */}
            <div className="flex items-start space-x-4 bg-teal-700/50 p-5 rounded-lg shadow-md border border-teal-500/30">
              <div className="p-3 bg-blue-600 rounded-full shrink-0">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-semibold">Optimized Shopping Strategies</h3>
                <p className="text-sm text-white/90">
                  Get personalized shopping strategies that help you save money, time, or balance both.
                </p>
              </div>
            </div>
            
            {/* Feature card 3 */}
            <div className="flex items-start space-x-4 bg-green-800/50 p-5 rounded-lg shadow-md border border-green-600/30">
              <div className="p-3 bg-orange-500 rounded-full shrink-0">
                <Clock className="h-5 w-5 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-semibold">Save Time and Money</h3>
                <p className="text-sm text-white/90">
                  Stop wasting time comparing prices. We'll show you the best stores to visit based on your needs.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}