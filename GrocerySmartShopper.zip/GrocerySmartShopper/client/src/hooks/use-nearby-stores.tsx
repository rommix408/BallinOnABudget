import { useQuery } from '@tanstack/react-query';
import { Store } from '@/lib/types';
import { getQueryFn } from '@/lib/queryClient';
import { useUserPreferences } from './use-user-preferences';

// Define as a named function expression to avoid Fast Refresh issues
const useNearbyStoresHook = (userLocation: { lat: number; lng: number } | null) => {
  const { preferences } = useUserPreferences();
  const maxTravelDistance = preferences?.maxTravelDistance || 10;

  // Only fetch if we have user location
  const enabled = !!userLocation;
  
  // Build query key with location parameters
  const queryKey = userLocation 
    ? ['/api/stores/nearby', userLocation.lat, userLocation.lng, maxTravelDistance] 
    : ['/api/stores/nearby'];
  
  // Build URL with query parameters
  const queryFn = getQueryFn<Store[]>({ on401: 'returnNull' });
  
  const {
    data: stores,
    isLoading,
    error,
  } = useQuery<Store[]>({
    queryKey,
    queryFn: async ({ queryKey }) => {
      if (!userLocation) return [];
      
      const url = `/api/stores/nearby?lat=${userLocation.lat}&lng=${userLocation.lng}&radius=${maxTravelDistance}`;
      const response = await fetch(url);
      
      if (!response.ok) {
        // Try to parse the error message from the response
        try {
          const errorData = await response.json();
          const errorMessage = errorData.message || 'Failed to fetch nearby stores';
          const errorType = errorData.error || 'SERVER_ERROR';
          
          // Create a custom error with additional properties
          const error = new Error(errorMessage) as Error & { type?: string };
          error.type = errorType;
          
          // Show more helpful error messages based on error type
          if (errorType === 'API_KEY_MISSING' || errorType === 'API_KEY_ERROR') {
            console.error('Google Maps API key issue detected:', errorMessage);
            throw new Error('Location service unavailable. Please contact support (Error: Maps API)');
          } else if (errorType === 'INVALID_COORDINATES' || errorType === 'COORDINATE_ERROR') {
            console.error('Coordinate error:', errorMessage);
            throw new Error('Invalid location data. Please update your location and try again');
          }
          
          throw error;
        } catch (parseError) {
          // If we can't parse the JSON, just use the status text
          throw new Error(`Failed to fetch nearby stores: ${response.statusText}`);
        }
      }
      
      return response.json();
    },
    enabled,
  });

  const returnValue = {
    stores: stores || [],
    isLoading,
    error,
    maxTravelDistance,
  };
  
  return returnValue;
}

// Export as a const for React Fast Refresh compatibility
export const useNearbyStores = useNearbyStoresHook;