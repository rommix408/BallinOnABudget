import { createContext, ReactNode, useContext } from "react";
import {
  useQuery,
  useMutation,
  UseMutationResult,
  QueryClient,
  QueryClientProvider,
} from "@tanstack/react-query";
import { User as SelectUser } from "@shared/schema";
import { apiRequest, getQueryFn, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Types
type UserWithoutPassword = Omit<SelectUser, "password">;

type LoginData = {
  identifier: string; // Can be either email or phone
  password: string;
};

type RegisterData = {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  password: string;
};

interface AuthContextProps {
  user: UserWithoutPassword | null;
  isLoading: boolean;
  error: Error | null;
  loginMutation: UseMutationResult<UserWithoutPassword, Error, LoginData>;
  logoutMutation: UseMutationResult<void, Error, void>;
  registerMutation: UseMutationResult<UserWithoutPassword, Error, RegisterData>;
}

// Create context with a default value
const AuthContext = createContext<AuthContextProps | undefined>(undefined);

// Auth provider component
function AuthProviderInner({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  
  // Get current user data
  const {
    data: user,
    error,
    isLoading,
  } = useQuery<UserWithoutPassword | null>({
    queryKey: ["/api/user"],
    queryFn: getQueryFn<UserWithoutPassword | null>({ on401: "returnNull" }),
  });

  // Login Mutation
  const loginMutation = useMutation<UserWithoutPassword, Error, LoginData>({
    mutationFn: async (credentials: LoginData) => {
      const res = await apiRequest("POST", "/api/login", credentials);
      return await res.json();
    },
    onSuccess: (user: UserWithoutPassword) => {
      queryClient.setQueryData(["/api/user"], user);
      toast({
        title: "Login successful",
        description: `Welcome, ${user.firstName}!`,
      });
    },
    onError: (error: Error) => {
      // Try to extract more specific error details if available
      let errorMessage = error.message;
      try {
        // Check if the error message contains a JSON response
        const match = error.message.match(/\d+:\s*(.*)/);
        if (match && match[1]) {
          const errorData = JSON.parse(match[1]);
          errorMessage = errorData.details || errorData.message || error.message;
        }
      } catch (e) {
        // If parsing fails, use the original error message
      }
      
      toast({
        title: "Login failed",
        description: errorMessage,
        variant: "destructive",
      });
    },
  });

  // Register Mutation
  const registerMutation = useMutation<UserWithoutPassword, Error, RegisterData>({
    mutationFn: async (userData: RegisterData) => {
      const res = await apiRequest("POST", "/api/register", userData);
      return await res.json();
    },
    onSuccess: (user: UserWithoutPassword) => {
      queryClient.setQueryData(["/api/user"], user);
      toast({
        title: "Registration successful",
        description: `Welcome to Ballin' on a Budget, ${user.firstName}!`,
      });
    },
    onError: (error: Error) => {
      // Try to extract more specific error details if available
      let errorMessage = error.message;
      try {
        // Check if the error message contains a JSON response
        const match = error.message.match(/\d+:\s*(.*)/);
        if (match && match[1]) {
          const errorData = JSON.parse(match[1]);
          errorMessage = errorData.details || errorData.message || error.message;
        }
      } catch (e) {
        // If parsing fails, use the original error message
      }
      
      toast({
        title: "Registration failed",
        description: errorMessage,
        variant: "destructive",
      });
    },
  });

  // Logout Mutation
  const logoutMutation = useMutation<void, Error, void>({
    mutationFn: async () => {
      await apiRequest("POST", "/api/logout");
    },
    onSuccess: () => {
      queryClient.setQueryData(["/api/user"], null);
      toast({
        title: "Logged out",
        description: "You have been successfully logged out.",
      });
    },
    onError: (error: Error) => {
      // Try to extract more specific error details if available
      let errorMessage = error.message;
      try {
        // Check if the error message contains a JSON response
        const match = error.message.match(/\d+:\s*(.*)/);
        if (match && match[1]) {
          const errorData = JSON.parse(match[1]);
          errorMessage = errorData.details || errorData.message || error.message;
        }
      } catch (e) {
        // If parsing fails, use the original error message
      }
      
      toast({
        title: "Logout failed",
        description: errorMessage,
        variant: "destructive",
      });
    },
  });

  const contextValue: AuthContextProps = {
    user: user ?? null,
    isLoading,
    error,
    loginMutation,
    logoutMutation,
    registerMutation,
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
}

// Export the provider component
export function AuthProvider({ children }: { children: ReactNode }) {
  return <AuthProviderInner>{children}</AuthProviderInner>;
}

// Hook for consuming the auth context
export function useAuth(): AuthContextProps {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}