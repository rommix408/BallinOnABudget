import { useQuery, useMutation } from '@tanstack/react-query';
import { UserPreferences } from '@/lib/types';
import { apiRequest, queryClient, getQueryFn } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/use-auth';

// Define as named function expression to avoid Fast Refresh issues
const useUserPreferencesHook = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  
  const {
    data: preferences,
    isLoading,
    error,
  } = useQuery<UserPreferences>({
    queryKey: ['/api/user/preferences'],
    queryFn: getQueryFn({ on401: 'returnNull' }),
    // Only fetch preferences if the user is logged in
    enabled: !!user,
  });

  const updatePreferencesMutation = useMutation({
    mutationFn: async (newPreferences: Partial<UserPreferences>) => {
      const res = await apiRequest('PUT', '/api/user/preferences', newPreferences);
      return await res.json();
    },
    onSuccess: (data: UserPreferences) => {
      queryClient.setQueryData(['/api/user/preferences'], data);
      toast({
        title: 'Preferences updated',
        description: 'Your preferences have been saved successfully.',
      });
    },
    onError: async (error: any) => {
      console.error('Preference update error:', error);
      
      // Try to parse the error response
      let errorMessage = 'Failed to update preferences';
      let errorType = '';
      
      try {
        // If this is a Response object from fetch
        if (error instanceof Response) {
          const data = await error.json();
          errorMessage = data.message || errorMessage;
          errorType = data.error || '';
          console.log('Parsed error response:', data);
        } 
        // If this is an Error with response data (from axios or similar)
        else if (error.response) {
          const data = error.response.data || {};
          errorMessage = data.message || errorMessage;
          errorType = data.error || '';
          console.log('Error from response object:', data);
        }
        // Regular Error object
        else if (error instanceof Error) {
          errorMessage = error.message;
          // Try to extract error type from error message format "TYPE: message"
          if (error.message.includes(':')) {
            errorType = error.message.split(':')[0].trim();
          }
        }
      } catch (parseError) {
        console.error('Error parsing error response:', parseError);
      }
      
      // Handle address geocoding errors
      if (errorType === 'API_KEY_ERROR') {
        toast({
          title: 'Service Unavailable',
          description: 'Our location service is temporarily unavailable. The development team has been notified of this issue.',
          variant: 'destructive',
        });
        
        // Log additional debug info
        console.error('Maps API Key issue detected:', errorMessage);
        return;
      } 
      else if (errorType === 'ADDRESS_NOT_FOUND') {
        toast({
          title: 'Address Not Found',
          description: 'We couldn\'t find that address. Please check spelling or try a more specific address format.',
          variant: 'destructive',
        });
      } 
      else if (errorType === 'INVALID_ADDRESS') {
        toast({
          title: 'Invalid Address Format',
          description: 'Please provide a complete address with street, city, state/province, and postal code.',
          variant: 'destructive',
        });
      } 
      else if (['QUOTA_EXCEEDED', 'NETWORK_ERROR'].includes(errorType)) {
        toast({
          title: 'Service Temporarily Unavailable',
          description: 'Our location service is temporarily unavailable. Please try again later.',
          variant: 'destructive',
        });
      } 
      else {
        // Generic error toast for all other errors
        toast({
          title: 'Update Failed',
          description: errorMessage,
          variant: 'destructive',
        });
      }
    },
  });

  return {
    preferences,
    isLoading,
    error,
    updatePreferences: updatePreferencesMutation.mutate,
    isUpdating: updatePreferencesMutation.isPending,
  };
}

// Export as a const for React Fast Refresh compatibility
export const useUserPreferences = useUserPreferencesHook;