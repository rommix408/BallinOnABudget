import { useState, useEffect } from 'react';
import { useUserPreferences } from './use-user-preferences';
import { useAuth } from './use-auth';

// Default fallback location (San Francisco, CA) if all other methods fail
// This should rarely be used, but provides a safety net
const DEFAULT_LOCATION = {
  lat: 37.7749,
  lng: -122.4194
};

// Define as a named function expression to avoid Fast Refresh issues
const useUserLocationHook = () => {
  const { user } = useAuth();
  const { preferences } = useUserPreferences();
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [useRealtimeLocation, setUseRealtimeLocation] = useState(true);

  // Function to get real-time location
  const getRealTimeLocation = () => {
    if (!navigator.geolocation) {
      if (preferences?.homeLocation?.lat && preferences?.homeLocation?.lng) {
        // If geolocation isn't available but we have a saved location, use that
        setLocation({
          lat: preferences.homeLocation.lat,
          lng: preferences.homeLocation.lng
        });
        setError(null);
      } else {
        // No geolocation and no saved location, use default and show error
        setLocation(DEFAULT_LOCATION);
        setError('Geolocation is not supported by your browser');
      }
      setIsLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      // Success callback
      (position) => {
        const newLocation = {
          lat: position.coords.latitude,
          lng: position.coords.longitude
        };
        console.log('Using real-time browser location:', newLocation);
        setLocation(newLocation);
        setIsLoading(false);
        setError(null);
      },
      // Error callback
      (err) => {
        console.error('Geolocation error:', err);
        
        // Fall back to saved location if available
        if (preferences?.homeLocation?.lat && preferences?.homeLocation?.lng) {
          console.log('Falling back to saved home location in preferences');
          setLocation({
            lat: preferences.homeLocation.lat,
            lng: preferences.homeLocation.lng
          });
          setError('Using your saved home location. To use your current location, allow location access in your browser.');
        } else if (user) {
          // User is logged in but has no saved location
          setLocation(DEFAULT_LOCATION);
          setError('Please set your home address in your Profile to see nearby stores.');
        } else {
          // Not logged in and no saved location
          setLocation(DEFAULT_LOCATION);
          setError('Please log in to use your saved location or allow browser location access.');
        }
        
        setIsLoading(false);
      },
      { 
        enableHighAccuracy: true,
        timeout: 10000, // Increased timeout for better reliability
        maximumAge: 60000 // Cache location for 1 minute for better performance
      }
    );
  };
  
  // Use the saved home location from user preferences
  const useSavedHomeLocation = () => {
    if (preferences?.homeLocation?.lat && preferences?.homeLocation?.lng) {
      console.log('Using saved home location from preferences');
      setLocation({
        lat: preferences.homeLocation.lat,
        lng: preferences.homeLocation.lng
      });
      setIsLoading(false);
      setError(null);
    } else {
      setLocation(DEFAULT_LOCATION);
      setError('Please set your home address in your Profile to see nearby stores.');
      setIsLoading(false);
    }
  };

  useEffect(() => {
    setIsLoading(true);
    
    // Check user's location sharing preference
    const locationPref = preferences?.locationSharingPreference || 'while-using';
    
    // Determine location based on the sharing preference
    if (locationPref === 'always') {
      // Always use real-time location when possible
      console.log('Location preference: always - using real-time location');
      setUseRealtimeLocation(true);
      getRealTimeLocation();
    } 
    else if (locationPref === 'while-using') {
      // Only use real-time location when app is open (default)
      console.log('Location preference: while-using - using real-time location when app is active');
      
      // If manually toggled to not use real-time, respect that choice
      if (useRealtimeLocation) {
        getRealTimeLocation();
      } else {
        useSavedHomeLocation();
      }
    }
    else if (locationPref === 'never') {
      // Never use real-time location, always use saved home address
      console.log('Location preference: never - using saved home location only');
      setUseRealtimeLocation(false);
      useSavedHomeLocation();
    }
    else {
      // Unknown preference, use default behavior
      console.log('Unknown location preference, using default (while-using)');
      if (useRealtimeLocation) {
        getRealTimeLocation();
      } else {
        useSavedHomeLocation();
      }
    }
  }, [preferences, user, useRealtimeLocation]);

  // Expose method to toggle between real-time and saved location
  // This will only have an effect if locationSharingPreference is 'while-using'
  const toggleLocationMode = () => {
    // Only allow toggling if the preference is 'while-using'
    if (preferences?.locationSharingPreference === 'while-using') {
      setUseRealtimeLocation(!useRealtimeLocation);
    } else if (preferences?.locationSharingPreference === 'always') {
      // Cannot disable real-time location when preference is 'always'
      setUseRealtimeLocation(true); 
    } else if (preferences?.locationSharingPreference === 'never') {
      // Cannot enable real-time location when preference is 'never'
      setUseRealtimeLocation(false);
    }
  };

  const returnValue = { 
    location, 
    isLoading, 
    error, 
    useRealtimeLocation, 
    toggleLocationMode,
    locationSharingPreference: preferences?.locationSharingPreference || 'while-using'
  };
  
  return returnValue;
}

// Export as a const for React Fast Refresh compatibility
export const useUserLocation = useUserLocationHook;