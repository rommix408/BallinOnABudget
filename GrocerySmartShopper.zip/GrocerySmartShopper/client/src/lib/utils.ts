import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Format a US phone number with parentheses and hyphens
 * Converts digits-only string to format: (123) 456-7890
 * Strips all non-digit characters from input
 */
export function formatPhoneNumber(value: string): string {
  // Remove all non-digit characters
  const phoneDigits = value.replace(/\D/g, '');
  
  // Format phone number as user types
  if (phoneDigits.length === 0) {
    return '';
  } else if (phoneDigits.length <= 3) {
    return `(${phoneDigits}`;
  } else if (phoneDigits.length <= 6) {
    return `(${phoneDigits.slice(0, 3)}) ${phoneDigits.slice(3)}`;
  } else {
    return `(${phoneDigits.slice(0, 3)}) ${phoneDigits.slice(3, 6)}-${phoneDigits.slice(6, 10)}`;
  }
}

/**
 * Convert a formatted phone number to E.164 format (+1XXXXXXXXXX)
 * for storage in the database
 */
export function formatPhoneForStorage(formattedPhone: string): string {
  // Extract only the digits
  const digits = formattedPhone.replace(/\D/g, '');
  
  // Ensure it has 10 digits and add the +1 prefix
  if (digits.length === 10) {
    return `+1${digits}`;
  }
  
  // Return the original but stripped of non-digits if not complete
  return digits.length > 0 ? `+1${digits}` : '';
}

/**
 * Validate that a phone number has exactly 10 digits (US format)
 */
export function isValidUSPhoneNumber(value: string): boolean {
  const digitsOnly = value.replace(/\D/g, '');
  return digitsOnly.length === 10;
}
