import { QueryClient, QueryFunction } from "@tanstack/react-query";

/**
 * Process a response and throw a detailed error if the response is not ok
 * @param res The fetch Response object
 * @throws Error with formatted message and additional error details when possible
 */
async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    try {
      // Try to parse as JSON first
      const contentType = res.headers.get('content-type');
      
      if (contentType && contentType.includes('application/json')) {
        // Handle JSON error responses
        const errorData = await res.json();
        
        // Create an enhanced error object
        const error = new Error(errorData.message || `${res.status}: ${res.statusText}`) as Error & {
          status?: number;
          statusText?: string;
          data?: any;
          error?: string;
        };
        
        error.status = res.status;
        error.statusText = res.statusText;
        error.data = errorData;
        
        // Add the error type if available
        if (errorData.error) {
          error.error = errorData.error;
        }
        
        // Add better error message formatting for specific error types
        if (errorData.error === 'API_KEY_ERROR') {
          error.message = 'Location service unavailable. Please try again later.';
        }
        
        console.error('API Error:', {
          status: res.status,
          statusText: res.statusText,
          data: errorData
        });
        
        throw error;
      } else {
        // Handle non-JSON responses
        const text = await res.text();
        throw new Error(`${res.status}: ${text || res.statusText}`);
      }
    } catch (parseError) {
      // If we can't parse the response at all
      if (parseError instanceof Error && parseError.message !== 'Unexpected end of JSON input') {
        throw parseError;
      }
      
      // Fallback to basic error
      throw new Error(`${res.status}: ${res.statusText}`);
    }
  }
}

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
): Promise<Response> {
  const res = await fetch(url, {
    method,
    headers: data ? { "Content-Type": "application/json" } : {},
    body: data ? JSON.stringify(data) : undefined,
    credentials: "include",
  });

  await throwIfResNotOk(res);
  return res;
}

export type UnauthorizedBehavior = "returnNull" | "throw";

export function getQueryFn<TData>(options: { on401: UnauthorizedBehavior }): QueryFunction<TData> {
  return async ({ queryKey }) => {
    const res = await fetch(queryKey[0] as string, {
      credentials: "include",
    });

    if (options.on401 === "returnNull" && res.status === 401) {
      return null as unknown as TData;
    }

    await throwIfResNotOk(res);
    return res.json() as Promise<TData>;
  };
}

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn<unknown>({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
