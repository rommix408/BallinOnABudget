import mongoose, { Schema, Document } from 'mongoose';

export interface IUserPreferences extends Document {
  userId: mongoose.Types.ObjectId | string | number; // Support multiple ID formats
  
  // Full address (for backward compatibility)
  homeAddress: string;
  
  // Expanded address components
  streetAddress: string;
  city: string;
  state: string;
  country: string;
  zipCode: string;
  
  // Geocoded location
  homeLocation: {
    type: 'Point';
    coordinates: [number, number]; // [lng, lat]
  };
  
  // User preference settings
  preferSaleItems: boolean;
  emailNotifications: boolean;
  smsNotifications: boolean;
  saveSearchHistory: boolean;
  maxTravelDistance: number; // in miles
  preferredStores: mongoose.Types.ObjectId[] | string[] | number[]; // Support multiple ID formats
  
  // Location sharing preference
  locationSharingPreference: string; // 'always', 'while-using', or 'never'
  
  // Timestamps
  createdAt: Date;
  updatedAt: Date;
}

const UserPreferencesSchema: Schema = new Schema({
  userId: {
    type: mongoose.Schema.Types.Mixed, // Allow both ObjectId and number formats
    ref: 'User',
    required: true,
    unique: true
  },
  // Full address (for backward compatibility)
  homeAddress: {
    type: String,
    trim: true,
    default: ''
  },
  // Expanded address components
  streetAddress: {
    type: String,
    trim: true,
    default: ''
  },
  city: {
    type: String,
    trim: true,
    default: ''
  },
  state: {
    type: String,
    trim: true,
    default: ''
  },
  country: {
    type: String,
    trim: true,
    default: 'United States'
  },
  zipCode: {
    type: String,
    trim: true,
    default: ''
  },
  // Geocoded location
  homeLocation: {
    type: {
      type: String,
      enum: ['Point'],
      default: 'Point'
    },
    coordinates: {
      type: [Number],
      default: [0, 0] // Default to [0,0] if not provided
    }
  },
  // User preference settings
  preferSaleItems: {
    type: Boolean,
    default: true
  },
  emailNotifications: {
    type: Boolean,
    default: true
  },
  smsNotifications: {
    type: Boolean,
    default: false
  },
  saveSearchHistory: {
    type: Boolean,
    default: true
  },
  maxTravelDistance: {
    type: Number,
    default: 10, // Default to 10 miles
    min: 1,
    max: 50
  },
  preferredStores: [{
    type: mongoose.Schema.Types.Mixed, // Allow multiple ID types
    ref: 'Store'
  }],
  // Location sharing preference
  locationSharingPreference: {
    type: String,
    enum: ['always', 'while-using', 'never'],
    default: 'while-using'
  }
}, {
  timestamps: true
});

// Add geospatial index for location-based queries
UserPreferencesSchema.index({ homeLocation: '2dsphere' });

export default mongoose.model<IUserPreferences>('UserPreferences', UserPreferencesSchema);