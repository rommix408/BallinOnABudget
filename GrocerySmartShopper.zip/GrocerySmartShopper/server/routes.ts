import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage, UserPreferences } from "./storage";
import { calculateStrategiesSchema, insertGroceryItemSchema } from "@shared/schema";
import { ZodError } from "zod";
import { default as dataScraperService } from './services/data-scraper';
import { scrapers } from './scrapers';
import StoreModel from './db/models/Store';
import { setupAuth } from "./auth";
import { z } from "zod";

// Schema for validating user preference updates
const updateUserPreferencesSchema = z.object({
  homeAddress: z.string().optional(),
  homeLocation: z.object({
    lat: z.number(),
    lng: z.number()
  }).optional(),
  zipCode: z.string().optional(),
  preferSaleItems: z.boolean().optional(),
  emailNotifications: z.boolean().optional(),
  smsNotifications: z.boolean().optional(),
  saveSearchHistory: z.boolean().optional(),
  maxTravelDistance: z.number().min(1).max(50).optional(),
  preferredStores: z.array(z.number()).optional()
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes and middleware
  setupAuth(app);
  
  // Middleware to check if user is authenticated
  const isAuthenticated = (req: Request, res: Response, next: NextFunction) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: 'You must be logged in to access this resource' });
  };
  app.get("/api/grocery-items", async (req, res) => {
    const userId = parseInt(req.query.userId as string) || 1;
    try {
      const items = await storage.getGroceryItems(userId);
      res.json(items);
    } catch {
      res.status(500).json({ message: "Failed to retrieve grocery items" });
    }
  });

  app.post("/api/grocery-items", async (req, res) => {
    try {
      const userId = req.body.userId || 1;
      const validatedData = insertGroceryItemSchema.parse({
        name: req.body.name,
        userId
      });
      const newItem = await storage.createGroceryItem(validatedData);
      res.status(201).json(newItem);
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({ message: "Invalid grocery item data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create grocery item" });
      }
    }
  });

  app.delete("/api/grocery-items/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid ID" });

      const success = await storage.deleteGroceryItem(id);
      if (success) res.json({ message: "Grocery item deleted successfully" });
      else res.status(404).json({ message: "Grocery item not found" });
    } catch {
      res.status(500).json({ message: "Failed to delete grocery item" });
    }
  });

  app.get("/api/stores", async (_, res) => {
    try {
      const stores = await storage.getStores();
      res.json(stores);
    } catch {
      res.status(500).json({ message: "Failed to retrieve stores" });
    }
  });

  app.post("/api/calculate-strategies", async (req, res) => {
    try {
      const validatedData = calculateStrategiesSchema.parse(req.body);
      if (validatedData.groceryItems.length === 0) {
        return res.status(400).json({ message: "Please add at least one grocery item" });
      }
      const strategies = await storage.calculateStrategies(validatedData.groceryItems);
      res.json(strategies);
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({ message: "Invalid request data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to calculate shopping strategies" });
      }
    }
  });

  app.post("/api/admin/initialize-stores", async (_, res) => {
    try {
      await dataScraperService.initializeStores();
      res.json({ message: "Stores initialized successfully" });
    } catch {
      res.status(500).json({ message: "Failed to initialize stores" });
    }
  });

  app.post("/api/admin/scrape-stores", async (_, res) => {
    try {
      await dataScraperService.scrapeAllStores();
      res.json({ message: "Store data scraped successfully" });
    } catch {
      res.status(500).json({ message: "Failed to scrape store data" });
    }
  });
  
  // Add specific store in Daly City area
  app.post("/api/admin/add-local-stores", async (_, res) => {
    try {
      // Add Lucky and Smart & Final in the Mission Plaza area
      const StoreModel = require('./db/models/Store').default;
      
      // Check if stores already exist
      const existingLucky = await StoreModel.findOne({ name: "Lucky" });
      const existingSmartAndFinal = await StoreModel.findOne({ name: "Smart & Final" });
      
      if (!existingLucky) {
        await StoreModel.create({
          name: "Lucky",
          address: "Mission Plaza, Daly City, CA 94014",
          lat: 37.7062,
          lng: -122.4647,
          location: {
            type: "Point",
            coordinates: [-122.4647, 37.7062] // [lng, lat]
          }
        });
      }
      
      if (!existingSmartAndFinal) {
        await StoreModel.create({
          name: "Smart & Final",
          address: "1200 El Camino Real, Colma, CA 94014",
          lat: 37.6773,
          lng: -122.4579,
          location: {
            type: "Point",
            coordinates: [-122.4579, 37.6773] // [lng, lat]
          }
        });
      }
      
      res.json({ message: "Local stores added successfully" });
    } catch (error) {
      console.error("Failed to add local stores:", error);
      res.status(500).json({ message: "Failed to add local stores" });
    }
  });

  app.get("/api/scrape/:store", async (req, res) => {
    const store = req.params.store;
    if (!scrapers[store]) {
      return res.status(404).json({ message: `No scraper found for "${store}"` });
    }

    try {
      const data = await scrapers[store]();
      res.json({ store, data });
    } catch (error) {
      console.error(`❌ Error scraping ${store}:`, error);
      res.status(500).json({ message: `Failed to scrape ${store}` });
    }
  });

  app.get('/api/stores/nearby', async (req, res) => {
    const lat = parseFloat(req.query.lat as string);
    const lng = parseFloat(req.query.lng as string);
    const radiusInMiles = parseFloat(req.query.radius as string) || 10;

    if (isNaN(lat) || isNaN(lng)) {
      return res.status(400).json({ 
        message: 'Missing or invalid latitude/longitude.', 
        error: 'INVALID_COORDINATES' 
      });
    }
    
    // Validate Google Maps API key is available
    if (!process.env.GOOGLE_MAPS_API_KEY) {
      console.error('Google Maps API key is missing in environment variables');
      return res.status(500).json({ 
        message: 'Server configuration error: Google Maps API key is missing',
        error: 'API_KEY_MISSING'
      });
    }

    try {
      // Use the storage interface method for better consistency with strategy calculations
      const nearbyStores = await storage.getNearbyStores(lat, lng, radiusInMiles);
      
      // Send analytics data about the request
      console.log(`Sent ${nearbyStores.length} nearby stores to client. Request coordinates: ${lat},${lng}`);
      
      res.json(nearbyStores);
    } catch (error: any) {
      console.error('Error fetching nearby stores:', error);
      
      // Handle specific error cases
      if (error.message && error.message.includes('API key')) {
        return res.status(500).json({ 
          message: 'Google Maps API key error. Please contact support.',
          error: 'API_KEY_ERROR'
        });
      } else if (error.message && error.message.includes('coordinate')) {
        return res.status(400).json({ 
          message: 'Invalid location coordinates provided.',
          error: 'COORDINATE_ERROR'
        });
      }
      
      // Generic error response
      res.status(500).json({ 
        message: 'Failed to retrieve nearby stores.',
        error: 'SERVER_ERROR'
      });
    }
  });
  
  // User preferences routes - these require authentication
  app.get('/api/user/preferences', isAuthenticated, async (req, res) => {
    try {
      // Cast the user to get the ID
      const userId = Number(req.user!.id);
      
      const preferences = await storage.getUserPreferences(userId);
      if (!preferences) {
        // Return default preferences if none exist
        const defaultPreferences: UserPreferences = {
          userId,
          preferSaleItems: true,
          emailNotifications: true,
          smsNotifications: false,
          saveSearchHistory: true,
          maxTravelDistance: 10,
          preferredStores: []
        };
        return res.json(defaultPreferences);
      }
      
      res.json(preferences);
    } catch (error) {
      console.error('Error getting user preferences:', error);
      res.status(500).json({ message: 'Failed to get user preferences' });
    }
  });
  
  app.put('/api/user/preferences', isAuthenticated, async (req, res) => {
    try {
      const userId = Number(req.user!.id);
      
      // Validate preference data
      const validatedData = updateUserPreferencesSchema.parse(req.body);
      
      // Check if we need to update the home location with geocoding
      if (validatedData.homeAddress && validatedData.homeAddress.trim() !== '') {
        try {
          // Import geocoding function
          const { geocodeAddress } = await import('./services/geocoding');
          
          // Check for Google Maps API key
          if (!process.env.GOOGLE_MAPS_API_KEY) {
            console.error('Missing Google Maps API key in environment');
            throw new Error('Google Maps API key is required for geocoding addresses');
          }
          
          // Geocode the address to get coordinates
          const geocodeResult = await geocodeAddress(validatedData.homeAddress);
          
          if (geocodeResult) {
            console.log(`Geocoded address "${validatedData.homeAddress}" to:`, geocodeResult);
            
            // Add location coordinates to the validated data
            validatedData.homeLocation = {
              lat: geocodeResult.lat,
              lng: geocodeResult.lng
            };
            
            // Update the address to the formatted version if it's different
            if (geocodeResult.formattedAddress !== validatedData.homeAddress) {
              validatedData.homeAddress = geocodeResult.formattedAddress;
            }
          } else {
            console.warn(`Failed to geocode address: ${validatedData.homeAddress}`);
            // Return a more helpful error message to the user
            return res.status(400).json({ 
              message: 'Could not convert your address to coordinates. Please check the address and try again.',
              addressError: true
            });
          }
        } catch (geocodeError: any) {
          console.error('Error geocoding address:', geocodeError);
          
          // Parse the error message to extract error type prefix
          const errorMessage = geocodeError.message || '';
          const errorType = errorMessage.includes(':') ? errorMessage.split(':')[0] : 'UNKNOWN_ERROR';
          
          // Create user-friendly response based on error type
          switch (errorType) {
            case 'API_KEY_MISSING':
            case 'API_KEY_INVALID':
            case 'API_KEY_ERROR':
              return res.status(500).json({ 
                message: 'Server configuration error: Could not access mapping services',
                error: 'API_KEY_ERROR',
                addressError: true
              });
              
            case 'ADDRESS_NOT_FOUND':
            case 'NO_RESULTS':
              return res.status(400).json({ 
                message: 'Could not find that address. Please check the spelling or try a more specific address.',
                error: 'ADDRESS_NOT_FOUND',
                addressError: true
              });
              
            case 'QUOTA_EXCEEDED':
              return res.status(503).json({ 
                message: 'Our location service is temporarily unavailable. Please try again later.',
                error: 'QUOTA_EXCEEDED',
                addressError: true
              });
              
            case 'INVALID_ADDRESS':
            case 'INVALID_REQUEST':
              return res.status(400).json({ 
                message: 'The address format is not valid. Please provide a complete address with street, city, and zip code.',
                error: 'INVALID_ADDRESS',
                addressError: true
              });
              
            case 'NETWORK_ERROR':
              return res.status(503).json({ 
                message: 'Could not connect to location services. Please check your internet connection and try again.',
                error: 'NETWORK_ERROR',
                addressError: true
              });
              
            default:
              // For all other errors, provide a generic response
              return res.status(400).json({ 
                message: 'There was a problem processing your address. Please try a different format or contact support.',
                error: errorType,
                errorDetails: errorMessage,
                addressError: true
              });
          }
        }
      }
      
      // Update the preferences
      const updatedPreferences = await storage.updateUserPreferences(userId, validatedData);
      
      res.json(updatedPreferences);
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({ message: 'Invalid preference data', errors: error.errors });
      } else {
        console.error('Error updating user preferences:', error);
        res.status(500).json({ message: 'Failed to update user preferences' });
      }
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
