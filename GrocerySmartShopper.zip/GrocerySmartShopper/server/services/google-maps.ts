import dotenv from 'dotenv';

dotenv.config();

// Check if the GOOGLE_MAPS_API_KEY is available
const GOOGLE_MAPS_API_KEY = process.env.GOOGLE_MAPS_API_KEY;

// Define a custom error class for Google Maps API errors
class GoogleMapsError extends Error {
  errorType: string;
  
  constructor(errorType: string, message: string) {
    super(`${errorType}: ${message}`);
    this.errorType = errorType;
    this.name = 'GoogleMapsError';
  }
}

interface DistanceMatrixResult {
  distance: {
    text: string;
    value: number; // in meters
  };
  duration: {
    text: string;
    value: number; // in seconds
  };
  status: string;
}

/**
 * Calculate distance and duration between user location and store
 * @param userLat User's latitude
 * @param userLng User's longitude
 * @param storeLat Store's latitude
 * @param storeLng Store's longitude
 * @returns Distance and duration
 */
export async function calculateDistanceMatrix(
  userLat: number, 
  userLng: number, 
  storeLat: number, 
  storeLng: number
): Promise<DistanceMatrixResult | null> {
  if (!GOOGLE_MAPS_API_KEY) {
    console.error('GOOGLE_MAPS_API_KEY is not available. Please set it in your environment variables.');
    throw new GoogleMapsError('API_KEY_MISSING', 'Google Maps API key is missing in environment variables');
  }

  // Basic check for API key format
  if (GOOGLE_MAPS_API_KEY.length < 20) {
    console.error('GOOGLE_MAPS_API_KEY appears to be invalid (too short)');
    throw new GoogleMapsError('API_KEY_INVALID', 'Google Maps API key appears to be invalid or incomplete');
  }

  // Validate coordinates before making API call to save resources and prevent errors
  if (!userLat || !userLng || !storeLat || !storeLng || 
      isNaN(userLat) || isNaN(userLng) || isNaN(storeLat) || isNaN(storeLng)) {
    console.error('Invalid coordinates provided:', { userLat, userLng, storeLat, storeLng });
    throw new GoogleMapsError('COORDINATE_ERROR', 'Invalid or missing coordinates provided for distance calculation');
  }
  
  // Check for reasonable coordinate values
  if (Math.abs(userLat) > 90 || Math.abs(userLng) > 180 || 
      Math.abs(storeLat) > 90 || Math.abs(storeLng) > 180) {
    console.error('Coordinates out of bounds:', { userLat, userLng, storeLat, storeLng });
    throw new GoogleMapsError('COORDINATE_ERROR', 'Coordinate values are out of bounds');
  }
  
  try {
    const url = new URL('https://maps.googleapis.com/maps/api/distancematrix/json');
    
    // Set query parameters
    url.searchParams.append('origins', `${userLat},${userLng}`);
    url.searchParams.append('destinations', `${storeLat},${storeLng}`);
    url.searchParams.append('mode', 'driving');
    url.searchParams.append('key', GOOGLE_MAPS_API_KEY);

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout
    
    try {
      const response = await fetch(url.toString(), { 
        signal: controller.signal 
      });
      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorText = await response.text();
        console.error('Google Maps API HTTP error:', {
          status: response.status,
          statusText: response.statusText,
          responseText: errorText
        });
        
        if (response.status === 403) {
          throw new GoogleMapsError('API_KEY_ERROR', 'Google Maps API key is invalid or has insufficient permissions');
        } else if (response.status === 429) {
          throw new GoogleMapsError('QUOTA_EXCEEDED', 'Google Maps API quota has been exceeded');
        } else {
          throw new GoogleMapsError('HTTP_ERROR', `Google Maps API returned status ${response.status}`);
        }
      }

      const data = await response.json();
      
      // Check the API response status
      if (data.status !== 'OK') {
        console.error('Google Maps API service error:', {
          apiStatus: data.status,
          errorMessage: data.error_message
        });
        
        if (data.status === 'INVALID_REQUEST') {
          throw new GoogleMapsError('INVALID_REQUEST', 'The request to Google Maps API was invalid');
        } else if (data.status === 'OVER_QUERY_LIMIT') {
          throw new GoogleMapsError('QUOTA_EXCEEDED', 'Google Maps API query limit exceeded');
        } else if (data.status === 'REQUEST_DENIED') {
          throw new GoogleMapsError('API_KEY_ERROR', 'Google Maps API key is invalid or has insufficient permissions');
        } else if (data.status === 'UNKNOWN_ERROR') {
          throw new GoogleMapsError('GOOGLE_MAPS_ERROR', 'Google Maps API service is experiencing issues');
        } else {
          throw new GoogleMapsError('GOOGLE_MAPS_ERROR', data.status);
        }
      }
      
      // Check if the API returned all the needed data
      if (
        data.rows && 
        data.rows.length > 0 && 
        data.rows[0].elements && 
        data.rows[0].elements.length > 0
      ) {
        const element = data.rows[0].elements[0];
        
        if (element.status === 'OK') {
          return {
            distance: element.distance,
            duration: element.duration,
            status: 'OK'
          };
        } else if (element.status === 'ZERO_RESULTS') {
          console.warn('No route found between the locations');
          return {
            distance: { text: 'N/A', value: 0 },
            duration: { text: 'N/A', value: 0 },
            status: 'NO_ROUTE'
          };
        } else if (element.status === 'NOT_FOUND') {
          throw new GoogleMapsError('LOCATION_ERROR', 'One or more locations could not be geocoded');
        } else {
          throw new GoogleMapsError('ROUTE_ERROR', element.status);
        }
      }
      
      console.error('Invalid or unexpected response structure from Google Maps API:', data);
      throw new GoogleMapsError('UNEXPECTED_RESPONSE', 'Google Maps API returned unexpected data structure');
    } catch (unknownError) {
      clearTimeout(timeoutId);
      
      const fetchError = unknownError as Error;
      if (fetchError.name === 'AbortError') {
        throw new GoogleMapsError('TIMEOUT', 'Google Maps API request timed out');
      }
      throw fetchError; // Re-throw to be caught by the outer try-catch
    }
  } catch (unknownError) {
    const error = unknownError as Error;
    console.error('Error calculating distance matrix:', error);
    
    // If it's already our custom GoogleMapsError, just pass it through
    if (error instanceof GoogleMapsError) {
      throw error;
    }
    
    // Check for network errors
    if (error instanceof TypeError && error.message.includes('network')) {
      throw new GoogleMapsError('NETWORK_ERROR', 'Unable to connect to Google Maps API');
    }
    
    // Generic error with the original message
    throw new GoogleMapsError('GOOGLE_MAPS_ERROR', error.message || 'Unknown error');
  }
}

/**
 * Convert distance matrix results to store model format
 * @param distanceMatrix Distance matrix result
 * @returns Distance in miles and travel time in minutes
 */
export function formatDistanceMatrix(distanceMatrix: DistanceMatrixResult): { distance: number, travelTime: number } {
  // Handle cases where the API might return a status other than OK
  if (distanceMatrix.status !== 'OK' || !distanceMatrix.distance || !distanceMatrix.duration) {
    console.warn('Invalid distance matrix result received:', distanceMatrix);
    return {
      distance: 999, // Use a high value to indicate "far away"
      travelTime: 99  // Similarly high travel time
    };
  }
  
  // Convert meters to miles (1 meter = 0.000621371 miles)
  const distanceInMiles = distanceMatrix.distance.value * 0.000621371;
  
  // Convert seconds to minutes
  const travelTimeInMinutes = Math.ceil(distanceMatrix.duration.value / 60);
  
  // Check for reasonable values
  if (isNaN(distanceInMiles) || distanceInMiles < 0 || isNaN(travelTimeInMinutes) || travelTimeInMinutes < 0) {
    console.warn('Invalid distance or travel time values:', { distanceInMiles, travelTimeInMinutes });
    return {
      distance: 999,
      travelTime: 99
    };
  }
  
  return {
    distance: parseFloat(distanceInMiles.toFixed(1)),
    travelTime: travelTimeInMinutes
  };
}

export default { calculateDistanceMatrix, formatDistanceMatrix };