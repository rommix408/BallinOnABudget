import axios from 'axios';

interface GeocodingResponse {
  results: {
    geometry: {
      location: {
        lat: number;
        lng: number;
      };
    };
    formatted_address: string;
  }[];
  status: string;
}

/**
 * Convert an address to geographic coordinates using Google Maps Geocoding API
 * @param address The address to geocode
 * @returns Lat/lng coordinates and formatted address, or null if geocoding failed
 */
export async function geocodeAddress(address: string): Promise<{
  lat: number;
  lng: number;
  formattedAddress: string;
} | null> {
  try {
    // Validate the address input
    if (!address || address.trim() === '') {
      console.error('Empty or invalid address provided for geocoding');
      throw new Error('INVALID_ADDRESS: Please provide a valid address');
    }

    // Make sure we have a Google Maps API key
    if (!process.env.GOOGLE_MAPS_API_KEY) {
      console.error('No Google Maps API key found in environment variables');
      throw new Error('API_KEY_MISSING: Google Maps API key is missing. Please set the GOOGLE_MAPS_API_KEY environment variable.');
    }

    // Check if API key looks valid (basic format check)
    if (process.env.GOOGLE_MAPS_API_KEY.length < 20) {
      console.error('Google Maps API key appears to be invalid (too short)');
      throw new Error('API_KEY_INVALID: The Google Maps API key appears to be invalid or incomplete');
    }

    // Prepare the URL for the API request
    const encodedAddress = encodeURIComponent(address);
    const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodedAddress}&key=${process.env.GOOGLE_MAPS_API_KEY}`;
    
    // Make the geocoding request
    console.log(`Attempting to geocode address: "${address.substring(0, 15)}..."`);
    const response = await axios.get<GeocodingResponse>(url);
    
    // Handle specific Google API error statuses
    if (response.data.status !== 'OK') {
      console.error(`Geocoding error: Google API returned status ${response.data.status} for address "${address}"`);
      
      // Handle specific error cases
      switch (response.data.status) {
        case 'ZERO_RESULTS':
          throw new Error(`ADDRESS_NOT_FOUND: Could not find coordinates for "${address}". Please try a more specific address.`);
        case 'OVER_QUERY_LIMIT':
          throw new Error('QUOTA_EXCEEDED: Geocoding service quota exceeded. Please try again later.');
        case 'REQUEST_DENIED':
          throw new Error('API_KEY_ERROR: The request was denied. Check if the Google Maps API key is valid and has Geocoding API enabled.');
        case 'INVALID_REQUEST':
          throw new Error('INVALID_REQUEST: The geocoding request was invalid. Please check the address format.');
        default:
          throw new Error(`GEOCODING_ERROR: ${response.data.status}: Geocoding service error. Please try again later.`);
      }
    }
    
    // Check if we have results
    if (!response.data.results || response.data.results.length === 0) {
      console.error(`No geocoding results for address "${address}"`, response.data);
      throw new Error(`NO_RESULTS: No location data found for "${address}". Please try a different address.`);
    }
    
    // Extract the first result (most relevant)
    const result = response.data.results[0];
    const { lat, lng } = result.geometry.location;
    const formattedAddress = result.formatted_address;
    
    console.log(`Successfully geocoded address to: ${lat}, ${lng} (${formattedAddress})`);
    return {
      lat,
      lng,
      formattedAddress
    };
  } catch (error: any) {
    // Check for axios network errors
    if (error.isAxiosError) {
      console.error(`Network error geocoding address "${address}":`, error.message);
      throw new Error(`NETWORK_ERROR: Could not connect to Google Maps service. Please check your internet connection.`);
    }
    
    // If we already have a formatted error, just pass it through
    if (error.message && (
      error.message.includes('INVALID_ADDRESS:') ||
      error.message.includes('API_KEY_MISSING:') ||
      error.message.includes('API_KEY_INVALID:') ||
      error.message.includes('ADDRESS_NOT_FOUND:') ||
      error.message.includes('QUOTA_EXCEEDED:') ||
      error.message.includes('API_KEY_ERROR:') ||
      error.message.includes('INVALID_REQUEST:') ||
      error.message.includes('GEOCODING_ERROR:') ||
      error.message.includes('NO_RESULTS:') ||
      error.message.includes('NETWORK_ERROR:')
    )) {
      console.error(`Geocoding error for "${address}":`, error.message);
      throw error;
    }
    
    // Generic error fallback
    console.error(`Unexpected error geocoding address "${address}":`, error);
    throw new Error(`GEOCODING_ERROR: An unexpected error occurred while finding coordinates for your address.`);
  }
}